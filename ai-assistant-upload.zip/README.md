# 🎧 AI Помощник — голосовой ИИ в Bluetooth-наушник

Бесплатное Android-приложение. Говоришь wake-word → ИИ отвечает голосом в наушники.

## Структура файлов

```
ai-assistant/
├── www/
│   └── index.html          ← весь код приложения (JS + HTML)
├── package.json            ← зависимости (Capacitor)
├── capacitor.config.json   ← настройки Capacitor
├── README.md               ← эта инструкция
└── .github/
    └── workflows/
        └── build-apk.yml  ← автосборка APK на GitHub
```

## Технологии (всё бесплатно)

| Что | Зачем |
|-----|-------|
| Capacitor.js | Оборачивает HTML/JS в Android APK |
| Web Speech API | Распознавание голоса (встроен в Chrome) |
| Groq API | Быстрый бесплатный ИИ (llama3) |
| SpeechSynthesis API | Голосовой ответ (встроен в Android) |
| GitHub Actions | Автосборка APK бесплатно |
